import "./App.css";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Login from "./components/logIn/Login";
import SignUp from "./components/logIn/Signup";
import Error from "./components/errorPage/Error";
import Inventory from "./components/landingPage/Inventory";
import Profile from "./components/landingPage/Profile";
import EmergencyList from "./components/landingPage/EmergencyList";
import Analytics from "./components/landingPage/Analytics";
import LandingPage from "./components/landingPage/LandingPage";
import DashBoard from "./components/landingPage/DashBoard";
import AddEditProduct from "./components/addEditProduct/AddEditProduct";
import CreateOrder from "./components/landingPage/CreateOrder";
import OrderHistory from "./components/landingPage/OrderHistory";
import { useState } from "react";
import OrderDetails from "./components/landingPage/OrderDetails";

function App() {
  const [emergencyList, setEmergencyList] = useState([]);

  const router = createBrowserRouter([
    {
      path: "/",
      element: <Login />,
      errorElement: <Error />,
    },

    {
      path: "/signup",
      element: <SignUp />,
      errorElement: <Error />,
    },

    {
      path: "/landingpage",
      element: <LandingPage />,
      children: [
        {
          path: "/landingpage/dashboard",
          element: <DashBoard />,
          errorElement: <Error />,
        },

        {
          path: "/landingpage/profile",
          element: <Profile />,
          errorElement: <Error />,
        },

        {
          path: "/landingpage/inventory",
          element: <Inventory setEmergencyList={setEmergencyList} />,
          errorElement: <Error />,
        },

        {
          path: "/landingpage/inventory/addeditproduct",
          element: <AddEditProduct />,
          errorElement: <Error />,
        },

        {
          path: "/landingpage/analytics",
          element: <Analytics />,
          errorElement: <Error />,
        },

        {
          path: "/landingpage/createorder",
          element: <CreateOrder />,
          errorElement: <Error />,
        },

        {
          path: "/landingpage/emergencylist",
          element: <EmergencyList emergencyList={emergencyList} />,
          errorElement: <Error />,
        },

        {
          path: "/landingpage/orderhistory",
          element: <OrderHistory />,
          errorElement: <Error />,
        },

        {
          path: "/landingpage/orderhistory/orderdetails",
          element: <OrderDetails />,
          errorElement: <Error />,
        },
      ],
      errorElement: <Error />,
    },

    {
      path: "*",
      element: <Error />,
    },
  ]);

  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

export default App;
