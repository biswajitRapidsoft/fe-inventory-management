import React from "react";

export default function Footer() {
  return (
    <>
      <div className="footer">
        <h3>Copyright &copy; 2024</h3>
      </div>
    </>
  );
}
