// import React, { useContext, useEffect, useState } from "react";
// import { ProductContext } from "./ProductProvider";
// import { apiEndPoint, baseUrl } from "../../config/config";
// import axios from "axios";

// export default function Analytics() {
//   const adminDetails = JSON.parse(localStorage.getItem("loginDetails"));
//   const [products, setProducts] = useState([]);
//   const [orders, setOrders] = useState([]);

//   const mockInventoryData = [
//     {
//       productId: 1,
//       productName: "Notebook",
//       productType: "Stationary",
//       quantity: 52,
//       minimumQuantity: 10,
//       costPrice: 15.0,
//       sellingPrice: 30.0,
//       productCode: "PR000",
//       adminId: 1,
//       isActive: true,
//     },
//     {
//       productId: 2,
//       productName: "Apple iPad",
//       productType: "Electronics",
//       quantity: 29,
//       minimumQuantity: 6,
//       costPrice: 40000.0,
//       sellingPrice: 60000.0,
//       productCode: "PR001",
//       adminId: 1,
//       isActive: true,
//     },
//     {
//       productId: 3,
//       productName: "Pen",
//       productType: "Stationary",
//       quantity: 48,
//       minimumQuantity: 10,
//       costPrice: 10.0,
//       sellingPrice: 25.0,
//       productCode: "PR002",
//       adminId: 1,
//       isActive: true,
//     },
//   ];

//   const mockOrderData = [
//     {
//       customerName: "Naveen Pattanayak",
//       phoneNo: "9087754324",
//       description: "The Lotus Flower Is Beautiful.",
//       totalAmount: 60250.0,
//       date: "2024-06-05T09:52:49.889+00:00",
//       soldBy: 1,
//       transactionId: "TR001",
//       products: [
//         {
//           productCode: "PR001",
//           quantity: 1,
//           totalPrice: 60000.0,
//           sellingPrice: 60000.0,
//           productName: "Apple iPad",
//         },
//         {
//           productCode: "PR002",
//           quantity: 10,
//           totalPrice: 250.0,
//           sellingPrice: 25.0,
//           productName: "Pen",
//         },
//       ],
//     },
//     {
//       customerName: "Yash Jain",
//       phoneNo: "127639128340",
//       description:
//         "We bring life to your aquarium. We sell live aquarium plants.",
//       totalAmount: 790.0,
//       date: "2024-06-05T09:54:03.442+00:00",
//       soldBy: 1,
//       transactionId: "TR002",
//       products: [
//         {
//           productCode: "PR000",
//           quantity: 8,
//           totalPrice: 240.0,
//           sellingPrice: 30.0,
//           productName: "Notebook",
//         },
//         {
//           productCode: "PR002",
//           quantity: 22,
//           totalPrice: 550.0,
//           sellingPrice: 25.0,
//           productName: "Pen",
//         },
//       ],
//     },
//   ];

//   useEffect(() => {
//     // fetchProducts();
//     // fetchOrderHistory();

//     setProducts(mockInventoryData);
//     setOrders(mockOrderData);
//   }, []);

//   // const fetchProducts = async () => {
//   //   try {
//   //     const response = await axios.get(
//   //       `${baseUrl}${apiEndPoint.allProduct}?adminId=${adminDetails.adminId}`,
//   //       {
//   //         headers: {
//   //           Authorization: "Bearer " + adminDetails?.jwtToken,
//   //         },
//   //       }
//   //     );
//   //     const products = response.data;
//   //     setProducts(products);
//   //   } catch (error) {
//   //     console.error("Error fetching products:", error);
//   //   }
//   // };

//   // const fetchOrderHistory = async () => {
//   //   try {
//   //     const response = await axios.get(
//   //       `${baseUrl}${apiEndPoint.orderHistory}?adminId=${adminDetails.adminId}`,
//   //       {
//   //         headers: {
//   //           Authorization: "Bearer " + adminDetails?.jwtToken,
//   //         },
//   //       }
//   //     );
//   //     setOrders(response.data);
//   //   } catch (error) {
//   //     console.error("Error fetching order history:", error);
//   //   }
//   // };

//   const calculateTotalStockAmount = (inventoryData) => {
//     return inventoryData.reduce(
//       (total, product) => total + product.quantity * product.costPrice,
//       0
//     );
//   };

//   const calculateTotalSalesCount = (orderData) => {
//     return orderData.reduce((total, order) => total + order.products.length, 0);
//   };

//   const calculateTotalSalesAmount = (orderData) => {
//     return orderData.reduce((total, order) => total + order.totalAmount, 0);
//   };

//   const calculateTotalProfit = (inventoryData, orderData) => {
//     let totalProfit = 0;
//     orderData.forEach((order) => {
//       order.products.forEach((product) => {
//         const soldQuantity = product.quantity;
//         const soldPrice = product.totalPrice;
//         const costPrice = inventoryData.find(
//           (item) => item.productCode === product.productCode
//         ).costPrice;
//         totalProfit += soldPrice - costPrice * soldQuantity;
//       });
//     });
//     return totalProfit;
//   };
//   const calculateActiveProductsCount = (inventoryData) => {
//     return inventoryData.filter((product) => product.isActive).length;
//   };

//   const totalStockAmount = calculateTotalStockAmount(mockInventoryData);
//   const totalSalesCount = calculateTotalSalesCount(mockOrderData);
//   const totalSalesAmount = calculateTotalSalesAmount(mockOrderData);
//   const totalProfit = calculateTotalProfit(mockInventoryData, mockOrderData);
//   const activeProductsCount = calculateActiveProductsCount(mockInventoryData);
//   const calculateProductsBelowMinimumQuantity = (inventoryData) => {
//     return inventoryData.filter(
//       (product) => product.quantity < product.minimumQuantity
//     ).length;
//   };

//   const productsBelowMinimumQuantityCount =
//     calculateProductsBelowMinimumQuantity(mockInventoryData);

//   return (
//     <>
//       <div className="analytics">
//         <div className="counts">
//           <div className="total-stock-amount">
//             <h3>Total Stock Amount:</h3>
//             <h3>₹ {totalStockAmount}</h3>
//           </div>

//           <div className="total-sale-count">
//             <h3>Total Sales Count:</h3>
//             <h3>{mockOrderData.length}</h3>
//           </div>

//           <div className="sales-to-date">
//             <h3>Total Sales Amount:</h3>
//             <h3>
//               ₹{" "}
//               {mockOrderData.reduce(
//                 (total, order) => total + order.totalAmount,
//                 0
//               )}
//             </h3>
//           </div>

//           <div className="total-profit">
//             <h3>Total Profit:</h3>
//             <h3>₹ {totalProfit}</h3>
//           </div>

//           <div className="active-products-count">
//             <h3>Active Products Count:</h3>
//             <h3>{activeProductsCount}</h3>
//           </div>

//           <div className="products-below-min-quantity-count">
//             <h3>Products Below Minimum Quantity:</h3>
//             <h3>{productsBelowMinimumQuantityCount}</h3>
//           </div>
//         </div>

//         <div className="graphs">
//           <div className="graph1">
//             <h1>Graph-1</h1>
//           </div>

//           <div className="graph2">
//             <h1>Graph-2</h1>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

import React, { useContext, useEffect, useState } from "react";
import { ProductContext } from "./ProductProvider";
import { apiEndPoint, baseUrl } from "../../config/config";
import axios from "axios";

export default function Analytics() {
  const adminDetails = JSON.parse(localStorage.getItem("loginDetails"));
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchProducts();
    fetchOrderHistory();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(
        `${baseUrl}${apiEndPoint.allProduct}?adminId=${adminDetails.adminId}`,
        {
          headers: {
            Authorization: "Bearer " + adminDetails?.jwtToken,
          },
        }
      );
      const products = response.data;
      setProducts(products);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  const fetchOrderHistory = async () => {
    try {
      const response = await axios.get(
        `${baseUrl}${apiEndPoint.orderHistory}?adminId=${adminDetails.adminId}&page=0&size=10`,
        {
          headers: {
            Authorization: "Bearer " + adminDetails?.jwtToken,
          },
        }
      );
      setOrders(response.data);
    } catch (error) {
      console.error("Error fetching order history:", error);
    }
  };

  const calculateTotalStockAmount = (inventoryData) => {
    return inventoryData.reduce(
      (total, product) => total + product.quantity * product.costPrice,
      0
    );
  };

  const calculateTotalSalesCount = (orderData) => {
    return orderData.reduce((total, order) => total + order.products.length, 0);
  };

  const calculateTotalSalesAmount = (orderData) => {
    return orderData.reduce((total, order) => total + order.totalAmount, 0);
  };

  const calculateTotalProfit = (inventoryData, orderData) => {
    let totalProfit = 0;
    orderData.forEach((order) => {
      order.products.forEach((product) => {
        const soldQuantity = product.quantity;
        const soldPrice = product.totalPrice;
        const costPrice = inventoryData.find(
          (item) => item.productCode === product.productCode
        ).costPrice;
        totalProfit += soldPrice - costPrice * soldQuantity;
      });
    });
    return totalProfit;
  };

  const calculateActiveProductsCount = (inventoryData) => {
    return inventoryData.filter((product) => product.isActive).length;
  };

  const calculateProductsBelowMinimumQuantity = (inventoryData) => {
    return inventoryData.filter(
      (product) => product.quantity < product.minimumQuantity
    ).length;
  };

  const totalStockAmount = calculateTotalStockAmount(products);
  const totalSalesCount = calculateTotalSalesCount(orders);
  const totalSalesAmount = calculateTotalSalesAmount(orders);
  const totalProfit = calculateTotalProfit(products, orders);
  const activeProductsCount = calculateActiveProductsCount(products);
  const productsBelowMinimumQuantityCount =
    calculateProductsBelowMinimumQuantity(products);

  return (
    <>
      <div className="analytics">
        <div className="counts">
          <div className="total-stock-amount">
            <h3>Total Stock Amount:</h3>
            <h3>₹ {totalStockAmount}</h3>
          </div>

          <div className="total-sale-count">
            <h3>Total Sales Count:</h3>
            <h3>{totalSalesCount}</h3>
          </div>

          <div className="sales-to-date">
            <h3>Total Sales Amount:</h3>
            <h3>₹ {totalSalesAmount}</h3>
          </div>

          <div className="total-profit">
            <h3>Total Profit:</h3>
            <h3>₹ {totalProfit}</h3>
          </div>

          <div className="active-products-count">
            <h3>Active Products Count:</h3>
            <h3>{activeProductsCount}</h3>
          </div>

          <div className="products-below-min-quantity-count">
            <h3>Products Below Minimum Quantity:</h3>
            <h3>{productsBelowMinimumQuantityCount}</h3>
          </div>
        </div>

        <div className="graphs">
          <div className="graph1">
            <h1>Graph-1</h1>
          </div>

          <div className="graph2">
            <h1>Graph-2</h1>
          </div>
        </div>
      </div>
    </>
  );
}
