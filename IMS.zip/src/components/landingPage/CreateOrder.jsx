// import { Grid, TextField, Typography, Button, IconButton } from "@mui/material";
// import React, { useEffect, useState } from "react";
// import Table from "@mui/material/Table";
// import TableBody from "@mui/material/TableBody";
// import TableCell from "@mui/material/TableCell";
// import TableContainer from "@mui/material/TableContainer";
// import TableHead from "@mui/material/TableHead";
// import TableRow from "@mui/material/TableRow";
// import TableFooter from "@mui/material/TableFooter";
// import Paper from "@mui/material/Paper";
// import axios from "axios";
// import { apiEndPoint, baseUrl } from "../../config/config";
// import DeleteIcon from "@mui/icons-material/Delete";

// export default function CreateOrder() {
//   const [searchQuery, setSearchQuery] = useState("");
//   const [customerName, setCustomerName] = useState("");
//   const [customerPhoneNo, setCustomerPhoneNo] = useState("");
//   const [description, setDescription] = useState("");
//   const [products, setProducts] = useState([]);
//   const [addedProducts, setAddedProducts] = useState([]);
//   const adminDetails = JSON.parse(localStorage.getItem("loginDetails"));

//   useEffect(() => {
//     fetchProducts();
//   }, []);

//   const fetchProducts = async () => {
//     try {
//       const response = await axios.get(
//         `${baseUrl}${apiEndPoint.allProduct}?adminId=${adminDetails.adminId}`,
//         {
//           headers: {
//             Authorization: "Bearer " + adminDetails?.jwtToken,
//           },
//         }
//       );
//       const fetchedProducts = response.data;
//       setProducts(fetchedProducts);
//     } catch (error) {
//       console.error("Error fetching products:", error);
//     }
//   };

//   const handleSearchChange = (e) => {
//     setSearchQuery(e.target.value);
//   };

//   const handleAddProduct = (product) => {
//     const newProduct = {
//       ...product,
//       purchaseQuantity: 1,
//       totalPrice: product.sellingPrice,
//     };
//     setAddedProducts((prev) => [...prev, newProduct]);
//   };

//   const handleQuantityChange = (productCode, quantity) => {
//     setAddedProducts((prev) =>
//       prev.map((product) =>
//         product.productCode === productCode
//           ? {
//               ...product,
//               purchaseQuantity: quantity,
//               totalPrice: product.sellingPrice * quantity,
//             }
//           : product
//       )
//     );
//   };

//   const handleRemoveProduct = (productCode) => {
//     setAddedProducts((prev) =>
//       prev.filter((product) => product.productCode !== productCode)
//     );
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();

//     const orderDetails = {
//       adminId: adminDetails.adminId,
//       customerName,
//       phoneNo: customerPhoneNo,
//       description,
//       totalAmount: totalCartPrice,
//       products: addedProducts.map((product) => ({
//         productId: product.productId,
//         productCode: product.productCode,
//         productName: product.productName,
//         quantity: product.purchaseQuantity,
//         sellingPrice: product.sellingPrice,
//         totalPrice: product.totalPrice,
//       })),
//     };

//     try {
//       const response = await axios.post(
//         `${baseUrl}${apiEndPoint.createOrder}`,
//         orderDetails,
//         {
//           headers: {
//             Authorization: "Bearer " + adminDetails?.jwtToken,
//           },
//         }
//       );

//       console.log("Order successfully created:", response.data);
//       setCustomerName("");
//       setCustomerPhoneNo("");
//       setDescription("");
//       setAddedProducts([]);
//     } catch (error) {
//       console.error("Error creating order:", error);
//     }
//   };

//   const filteredProducts = products.filter(
//     (product) =>
//       product.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
//       product.productCode.toString().includes(searchQuery)
//   );

//   const totalCartPrice = addedProducts.reduce(
//     (total, product) => total + product.totalPrice,
//     0
//   );

//   return (
//     <>
//       <Grid container className="create-order-container" gap={1}>
//         <Grid
//           item
//           xs={12}
//           className="search-product-result"
//           sx={{ height: "fit-content" }}
//         >
//           <Grid
//             item
//             xs={12}
//             className="order-product-search"
//             sx={{ height: "fit-content" }}
//           >
//             <input
//               className="order-search-inp"
//               type="text"
//               placeholder="Search by name or code"
//               value={searchQuery}
//               onChange={handleSearchChange}
//             />
//             <button className="search-btn" type="submit">
//               <h3>Search</h3>
//             </button>
//           </Grid>
//           {searchQuery && filteredProducts.length > 0 && (
//             <TableContainer component={Paper} sx={{ marginTop: "15px" }}>
//               <Table aria-label="simple table">
//                 <TableHead>
//                   <TableRow>
//                     <TableCell>Product Code</TableCell>
//                     <TableCell align="right">Product Name</TableCell>
//                     <TableCell align="right">Price</TableCell>
//                     <TableCell align="right">Action</TableCell>
//                   </TableRow>
//                 </TableHead>
//                 <TableBody>
//                   {filteredProducts.map((product) => (
//                     <TableRow
//                       key={product.productCode}
//                       sx={{
//                         "&:last-child td, &:last-child th": { border: 0 },
//                       }}
//                     >
//                       <TableCell component="th" scope="row">
//                         {product.productCode}
//                       </TableCell>
//                       <TableCell align="right">{product.productName}</TableCell>
//                       <TableCell align="right">
//                         {product.sellingPrice}
//                       </TableCell>
//                       <TableCell align="right">
//                         <Button
//                           variant="contained"
//                           color="primary"
//                           onClick={() => handleAddProduct(product)}
//                         >
//                           Add
//                         </Button>
//                       </TableCell>
//                     </TableRow>
//                   ))}
//                 </TableBody>
//               </Table>
//             </TableContainer>
//           )}
//         </Grid>

//         <Grid
//           item
//           xs={12}
//           className="create-order-form"
//           sx={{ height: "fit-content" }}
//         >
//           <Typography
//             variant="h5"
//             sx={{ textDecoration: "underline", marginBottom: "10px" }}
//             textAlign="center"
//           >
//             Check Out Form
//           </Typography>
//           <form onSubmit={handleSubmit}>
//             <Grid container spacing={2} className="checkout-customer-form">
//               <Grid item xs={4}>
//                 <TextField
//                   sx={{ bgcolor: "white" }}
//                   label="Customer's Name"
//                   id="customerName"
//                   name="customerName"
//                   variant="outlined"
//                   type="text"
//                   required
//                   fullWidth
//                   value={customerName}
//                   onChange={(e) => setCustomerName(e.target.value)}
//                 />
//               </Grid>

//               <Grid item xs={4}>
//                 <TextField
//                   sx={{ bgcolor: "white" }}
//                   label="Phone No."
//                   id="customerPhoneNo"
//                   name="customerPhoneNo"
//                   variant="outlined"
//                   type="text"
//                   required
//                   fullWidth
//                   value={customerPhoneNo}
//                   onChange={(e) => setCustomerPhoneNo(e.target.value)}
//                 />
//               </Grid>

//               <Grid item xs={4}>
//                 <TextField
//                   sx={{ bgcolor: "white" }}
//                   label="Description"
//                   id="description"
//                   name="description"
//                   variant="outlined"
//                   type="text"
//                   required
//                   fullWidth
//                   value={description}
//                   onChange={(e) => setDescription(e.target.value)}
//                 />
//               </Grid>
//             </Grid>

//             <TableContainer
//               component={Paper}
//               className="cart-table"
//               sx={{ marginTop: "15px" }}
//             >
//               <Table aria-label="simple table">
//                 <TableHead>
//                   <TableRow>
//                     <TableCell>Product Code</TableCell>
//                     <TableCell align="right">Product Name</TableCell>
//                     <TableCell align="right">Quantity</TableCell>
//                     <TableCell align="right">Total Price</TableCell>
//                     <TableCell align="right">Action</TableCell>
//                   </TableRow>
//                 </TableHead>
//                 {addedProducts.length > 0 && (
//                   <>
//                     <TableBody>
//                       {addedProducts.map((product) => (
//                         <TableRow
//                           key={product.productCode}
//                           sx={{
//                             "&:last-child td, &:last-child th": { border: 0 },
//                           }}
//                         >
//                           <TableCell component="th" scope="row">
//                             {product.productCode}
//                           </TableCell>
//                           <TableCell align="right">
//                             {product.productName}
//                           </TableCell>
//                           <TableCell align="right">
//                             <TextField
//                               type="number"
//                               value={product.purchaseQuantity}
//                               onChange={(e) =>
//                                 handleQuantityChange(
//                                   product.productCode,
//                                   Number(e.target.value)
//                                 )
//                               }
//                               inputProps={{ min: 0 }}
//                             />
//                           </TableCell>
//                           <TableCell align="right">
//                             {product.totalPrice}
//                           </TableCell>
//                           <TableCell align="right">
//                             <IconButton
//                               color="secondary"
//                               onClick={() =>
//                                 handleRemoveProduct(product.productCode)
//                               }
//                             >
//                               <DeleteIcon />
//                             </IconButton>
//                           </TableCell>
//                         </TableRow>
//                       ))}
//                     </TableBody>
//                     <TableFooter>
//                       <TableRow>
//                         <TableCell colSpan={3} align="right">
//                           <Typography variant="h6">Total Price:</Typography>
//                         </TableCell>
//                         <TableCell align="right">
//                           <Typography variant="h6">{totalCartPrice}</Typography>
//                         </TableCell>
//                       </TableRow>
//                     </TableFooter>
//                   </>
//                 )}
//               </Table>
//             </TableContainer>

//             <Grid
//               item
//               xs={12}
//               className="checkout-customer-form"
//               sx={{ height: "fit-content", marginTop: "15px" }}
//             >
//               <Button variant="contained" color="primary" type="submit">
//                 Check Out
//               </Button>
//             </Grid>
//           </form>
//         </Grid>
//       </Grid>
//     </>
//   );
// }

import { Grid, TextField, Typography, Button, IconButton } from "@mui/material";
import React, { useEffect, useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableFooter from "@mui/material/TableFooter";
import Paper from "@mui/material/Paper";
import axios from "axios";
import { apiEndPoint, baseUrl } from "../../config/config";
import DeleteIcon from "@mui/icons-material/Delete";

export default function CreateOrder() {
  const [searchQuery, setSearchQuery] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhoneNo, setCustomerPhoneNo] = useState("");
  const [description, setDescription] = useState("");
  const [products, setProducts] = useState([]);
  const [addedProducts, setAddedProducts] = useState([]);
  const adminDetails = JSON.parse(localStorage.getItem("loginDetails"));

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(
        `${baseUrl}${apiEndPoint.allProduct}?adminId=${adminDetails.adminId}`,
        {
          headers: {
            Authorization: "Bearer " + adminDetails?.jwtToken,
          },
        }
      );
      const fetchedProducts = response.data;
      setProducts(fetchedProducts);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleAddProduct = (product) => {
    const newProduct = {
      ...product,
      purchaseQuantity: 1,
      totalPrice: product.sellingPrice,
    };
    setAddedProducts((prev) => [...prev, newProduct]);
  };

  const handleQuantityChange = (productCode, quantity) => {
    setAddedProducts((prev) =>
      prev.map((product) =>
        product.productCode === productCode
          ? {
              ...product,
              purchaseQuantity: quantity,
              totalPrice: product.sellingPrice * quantity,
            }
          : product
      )
    );
  };

  const handleRemoveProduct = (productCode) => {
    setAddedProducts((prev) =>
      prev.filter((product) => product.productCode !== productCode)
    );
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const orderDetails = {
      adminId: adminDetails.adminId,
      customerName,
      phoneNo: customerPhoneNo,
      description,
      totalAmount: totalCartPrice,
      products: addedProducts.map((product) => ({
        productId: product.productId,
        productCode: product.productCode,
        productName: product.productName,
        quantity: product.purchaseQuantity,
        sellingPrice: product.sellingPrice,
        totalPrice: product.totalPrice,
      })),
    };

    try {
      const response = await axios.post(
        `${baseUrl}${apiEndPoint.createOrder}`,
        orderDetails,
        {
          headers: {
            Authorization: "Bearer " + adminDetails?.jwtToken,
          },
        }
      );

      console.log("Order successfully created:", response.data);
      setCustomerName("");
      setCustomerPhoneNo("");
      setDescription("");
      setAddedProducts([]);
    } catch (error) {
      console.error("Error creating order:", error);
    }
  };

  const filteredProducts = products.filter(
    (product) =>
      product.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.productCode.toString().includes(searchQuery)
  );

  const totalCartPrice = addedProducts.reduce(
    (total, product) => total + product.totalPrice,
    0
  );

  return (
    <>
      <Grid container className="create-order-container" gap={1}>
        <Grid
          item
          xs={12}
          className="search-product-result"
          sx={{ height: "fit-content" }}
        >
          <Grid
            item
            xs={12}
            className="order-product-search"
            sx={{ height: "fit-content" }}
          >
            <input
              className="order-search-inp"
              type="text"
              placeholder="Search by name or code"
              value={searchQuery}
              onChange={handleSearchChange}
            />
            <button className="search-btn" type="submit">
              <h3>Search</h3>
            </button>
          </Grid>
          {searchQuery && filteredProducts.length > 0 && (
            <TableContainer component={Paper} sx={{ marginTop: "15px" }}>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>Product Code</TableCell>
                    <TableCell align="right">Product Name</TableCell>
                    <TableCell align="right">Price</TableCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredProducts.map((product) => (
                    <TableRow
                      key={product.productCode}
                      sx={{
                        "&:last-child td, &:last-child th": { border: 0 },
                      }}
                    >
                      <TableCell component="th" scope="row">
                        {product.productCode}
                      </TableCell>
                      <TableCell align="right">{product.productName}</TableCell>
                      <TableCell align="right">
                        {product.sellingPrice}
                      </TableCell>
                      <TableCell align="right">
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={() => handleAddProduct(product)}
                        >
                          Add
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Grid>

        <Grid
          item
          xs={12}
          className="create-order-form"
          sx={{ height: "fit-content" }}
        >
          <Typography
            variant="h5"
            sx={{ textDecoration: "underline", marginBottom: "10px" }}
            textAlign="center"
          >
            Check Out Form
          </Typography>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2} className="checkout-customer-form">
              <Grid item xs={4}>
                <TextField
                  sx={{ bgcolor: "white" }}
                  label="Customer's Name"
                  id="customerName"
                  name="customerName"
                  variant="outlined"
                  type="text"
                  required
                  fullWidth
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                />
              </Grid>

              <Grid item xs={4}>
                <TextField
                  sx={{ bgcolor: "white" }}
                  label="Phone No."
                  id="customerPhoneNo"
                  name="customerPhoneNo"
                  variant="outlined"
                  type="text"
                  required
                  fullWidth
                  value={customerPhoneNo}
                  onChange={(e) => setCustomerPhoneNo(e.target.value)}
                />
              </Grid>

              <Grid item xs={4}>
                <TextField
                  sx={{ bgcolor: "white" }}
                  label="Description"
                  id="description"
                  name="description"
                  variant="outlined"
                  type="text"
                  required
                  fullWidth
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </Grid>
            </Grid>

            <TableContainer
              component={Paper}
              className="cart-table"
              sx={{ marginTop: "15px" }}
            >
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>Product Code</TableCell>
                    <TableCell align="right">Product Name</TableCell>
                    <TableCell align="right">Quantity</TableCell>
                    <TableCell align="right">Total Price</TableCell>
                    <TableCell align="right">Action</TableCell>
                  </TableRow>
                </TableHead>
                {addedProducts.length > 0 && (
                  <>
                    <TableBody>
                      {addedProducts.map((product) => (
                        <TableRow
                          key={product.productCode}
                          sx={{
                            "&:last-child td, &:last-child th": { border: 0 },
                          }}
                        >
                          <TableCell component="th" scope="row">
                            {product.productCode}
                          </TableCell>
                          <TableCell align="right">
                            {product.productName}
                          </TableCell>
                          <TableCell align="right">
                            <TextField
                              type="number"
                              value={product.purchaseQuantity}
                              onChange={(e) =>
                                handleQuantityChange(
                                  product.productCode,
                                  Math.min(
                                    Number(e.target.value),
                                    product.quantity
                                  )
                                )
                              }
                              inputProps={{
                                min: 0,
                                max: product.availableQuantity,
                              }}
                            />
                          </TableCell>
                          <TableCell align="right">
                            {product.totalPrice}
                          </TableCell>
                          <TableCell align="right">
                            <IconButton
                              color="dark"
                              onClick={() =>
                                handleRemoveProduct(product.productCode)
                              }
                            >
                              <DeleteIcon />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                    <TableFooter>
                      <TableRow>
                        <TableCell colSpan={3} align="right">
                          <Typography variant="h6">Total Price:</Typography>
                        </TableCell>
                        <TableCell align="right">
                          <Typography variant="h6">{totalCartPrice}</Typography>
                        </TableCell>
                      </TableRow>
                    </TableFooter>
                  </>
                )}
              </Table>
            </TableContainer>

            <Grid
              item
              xs={12}
              className="checkout-customer-form"
              sx={{ height: "fit-content", marginTop: "15px" }}
            >
              <Button variant="contained" color="primary" type="submit">
                Check Out
              </Button>
            </Grid>
          </form>
        </Grid>
      </Grid>
    </>
  );
}
