import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import { apiEndPoint, baseUrl } from "../../config/config";
import axios from "axios";
import { Doughnut } from "react-chartjs-2";

export default function DashBoard() {
  const adminDetails = JSON.parse(localStorage.getItem("loginDetails"));
  const [products, setProducts] = useState([]);
  const [totalStockAmount, setTotalStockAmount] = useState(0);
  const [totalSalesAmount, setTotalSalesAmount] = useState(0);
  const [totalProfit, setTotalProfit] = useState(0);
  const [activeProductsCount, setActiveProductsCount] = useState(0);
  const [categoryData, setCategoryData] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(
        `${baseUrl}${apiEndPoint.allProduct}?adminId=${adminDetails.adminId}`,
        {
          headers: {
            Authorization: "Bearer " + adminDetails?.jwtToken,
          },
        }
      );
      const fetchedProducts = response.data;
      setProducts(fetchedProducts);
      calculateTotals(fetchedProducts);
      prepareCategoryData(fetchedProducts);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  const calculateTotals = (products) => {
    let stockAmount = 0;
    let salesAmount = 0;
    let activeCount = 0;

    products.forEach((product) => {
      stockAmount += product.quantity * product.costPrice;
      salesAmount += product.quantity * product.sellingPrice;
      if (product.isActive) {
        activeCount++;
      }
    });

    setTotalStockAmount(stockAmount);
    setTotalSalesAmount(salesAmount);
    setTotalProfit(salesAmount - stockAmount);
    setActiveProductsCount(activeCount);
  };

  const prepareCategoryData = (products) => {
    const categoryCounts = products.reduce((acc, product) => {
      acc[product.productType] = (acc[product.productType] || 0) + 1;
      return acc;
    }, {});

    const labels = Object.keys(categoryCounts);
    const data = Object.values(categoryCounts);

    setCategoryData({
      labels,
      datasets: [
        {
          data,
          backgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56",
            "#4BC0C0",
            "#9966FF",
            "#FF9F40",
          ],
        },
      ],
    });
  };

  return (
    <>
      <div className="dashboard">
        <Grid container sx={{ margin: "10px" }}>
          <Grid item xs={12} container>
            <Grid item xs={3}>
              <div className="dashboard-active-products-count">
                <h3>Active Products Count:</h3>
                <h3>{activeProductsCount}</h3>
              </div>
            </Grid>

            <Grid item xs={3}>
              <div className="dashboard-total-stock-amount">
                <h3>Total Stock Amount:</h3>
                <h3>₹ {totalStockAmount.toLocaleString()}</h3>
              </div>
            </Grid>

            <Grid item xs={3}>
              <div className="dashboard-sales-to-date">
                <h3>Total Sales Amount:</h3>
                <h3>₹ {totalSalesAmount.toLocaleString()}</h3>
              </div>
            </Grid>

            <Grid item xs={3}>
              <div className="dashboard-total-profit">
                <h3>Total Profit:</h3>
                <h3>₹ {totalProfit.toLocaleString()}</h3>
              </div>
            </Grid>
          </Grid>

          <Grid item xs={12} container>
            <Grid item xs={6} container className="dashboard-graphs">
              <Grid item xs={12}>
                <div className="dashboard-graph1">
                  <h1>Graph-1 Histogram</h1>
                </div>
              </Grid>

              <Grid item xs={12}>
                <div className="dashboard-graph2">
                  <h1>Graph-2 Doughnut Chart</h1>
                  {/* <Doughnut data={categoryData} /> */}
                </div>
              </Grid>
            </Grid>

            <Grid item xs={6}>
              <div className="recent-sales">
                <h1>Recent Sales</h1>
              </div>
            </Grid>
          </Grid>
        </Grid>
      </div>
    </>
  );
}
