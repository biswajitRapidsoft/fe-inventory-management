import React from "react";
import { useNavigate } from "react-router-dom";
import {
  Grid,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";

export default function EmergencyList({ emergencyList }) {
  const navigate = useNavigate();

  const editProduct = (product) => {
    navigate("/landingpage/inventory/addeditproduct", { state: { product } });
  };

  return (
    <Grid container className="emergency-list-container">
      <Grid item xs={12} sx={{ height: "fit-content" }}>
        <Typography
          variant="h5"
          sx={{ textDecoration: "underline", marginBottom: "10px" }}
          textAlign="center"
        >
          Emergency List
        </Typography>
      </Grid>

      <Grid item xs={12} sx={{ height: "calc(100% - 42px)" }}>
        {emergencyList.length > 0 ? (
          <TableContainer
            component={Paper}
            className="emergency-list-table-container"
          >
            <Table aria-label="emergency list table" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell className="tHead">
                    <h4>Product Name</h4>
                  </TableCell>
                  <TableCell className="tHead" align="center">
                    <h4>Available Quantity</h4>
                  </TableCell>
                  <TableCell className="tHead" align="center">
                    <h4>Minimum Quantity</h4>
                  </TableCell>
                  <TableCell className="tHead" align="center">
                    <h4>Edit</h4>
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody className="emergency-list-tbody">
                {emergencyList.map((product) => (
                  <TableRow key={product.productId}>
                    <TableCell align="left">{product.productName}</TableCell>
                    <TableCell align="center">{product.quantity}</TableCell>
                    <TableCell align="center">
                      {product.minimumQuantity}
                    </TableCell>
                    <TableCell align="center">
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={() => editProduct(product)}
                      >
                        Edit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <Typography textAlign="center">No products found</Typography>
        )}
      </Grid>
    </Grid>
  );
}
