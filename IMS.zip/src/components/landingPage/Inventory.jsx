import React, { useEffect, useState } from "react";
import TablePagination from "@mui/material/TablePagination";
import Grid from "@mui/material/Grid";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { apiEndPoint, baseUrl } from "../../config/config";

export default function Inventory({ setEmergencyList }) {
  const adminDetails = JSON.parse(localStorage.getItem("loginDetails"));
  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const rowsPerPage = 6;

  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(
        `${baseUrl}${apiEndPoint.allProduct}?adminId=${adminDetails.adminId}`,
        {
          headers: {
            Authorization: "Bearer " + adminDetails?.jwtToken,
          },
        }
      );
      const products = response.data;
      setProducts(products);
      updateEmergencyList(products);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  const updateEmergencyList = (products) => {
    const emergencyList = products.filter(
      (product) => product.quantity < product.minimumQuantity
    );
    setEmergencyList(emergencyList);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
    setPage(0);
  };

  const updateProductStatus = async (product) => {
    try {
      const response = await axios.post(
        `${baseUrl}${apiEndPoint.addEditProduct}`,
        product,
        {
          headers: {
            Authorization: "Bearer " + adminDetails?.jwtToken,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error("Error updating product status:", error);
      return null;
    }
  };

  const toggleStatus = async (id) => {
    const product = products.find((product) => product.productId === id);
    if (product) {
      const newStatus = !product.isActive;
      const updatedProduct = await updateProductStatus({
        ...product,
        isActive: newStatus,
      });
      if (updatedProduct) {
        const updatedProducts = products.map((product) =>
          product.productId === id
            ? { ...product, isActive: newStatus }
            : product
        );
        setProducts(updatedProducts);
        updateEmergencyList(updatedProducts);
      }
    }
  };

  const filteredProducts = products?.filter(
    (product) =>
      product.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.productCode.toString().includes(searchQuery)
  );

  const emptyRows =
    rowsPerPage -
    Math.min(rowsPerPage, filteredProducts.length - page * rowsPerPage);

  const addProduct = () => {
    navigate("/landingpage/inventory/addeditproduct");
  };

  const editProduct = (product) => {
    navigate("/landingpage/inventory/addeditproduct", { state: { product } });
  };

  return (
    <div className="inventory">
      <Grid container>
        <Grid item xs={12}>
          <div className="search-addbtn">
            <div className="product-search">
              <input
                className="search-inp"
                type="text"
                placeholder="Search by name or code"
                value={searchQuery}
                onChange={handleSearchChange}
              />
              <button className="search-btn" type="submit">
                <h3>Search</h3>
              </button>
            </div>

            <div className="addbtn-div">
              <button className="add-btn" onClick={addProduct}>
                <h3>Add Product</h3>
              </button>
            </div>
          </div>
        </Grid>

        <Grid item xs={12}>
          <div className="table">
            <table>
              <thead>
                <tr>
                  <th>
                    <h3>Code</h3>
                  </th>
                  <th>
                    <h3>Product Name</h3>
                  </th>
                  <th>
                    <h3>Cost Price</h3>
                  </th>
                  <th>
                    <h3>Selling Price</h3>
                  </th>
                  <th>
                    <h3>Quantity</h3>
                  </th>
                  <th>
                    <h3>Edit</h3>
                  </th>
                  <th>
                    <h3>Status</h3>
                  </th>
                </tr>
              </thead>

              <tbody>
                {filteredProducts
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((product) => (
                    <tr key={product.productId}>
                      <td
                        style={{
                          color:
                            product.quantity < product.minimumQuantity
                              ? "red"
                              : "inherit",
                        }}
                      >
                        {product.productCode}
                      </td>
                      <td
                        style={{
                          color:
                            product.quantity < product.minimumQuantity
                              ? "red"
                              : "inherit",
                        }}
                      >
                        {product.productName}
                      </td>
                      <td
                        style={{
                          color:
                            product.quantity < product.minimumQuantity
                              ? "red"
                              : "inherit",
                        }}
                      >
                        {product.costPrice}
                      </td>
                      <td
                        style={{
                          color:
                            product.quantity < product.minimumQuantity
                              ? "red"
                              : "inherit",
                        }}
                      >
                        {product.sellingPrice}
                      </td>
                      <td
                        style={{
                          color:
                            product.quantity < product.minimumQuantity
                              ? "red"
                              : "inherit",
                        }}
                      >
                        {product.quantity}
                      </td>
                      <td>
                        <button
                          className="edit-btn"
                          onClick={() => editProduct(product)}
                        >
                          <h3>Edit</h3>
                        </button>
                      </td>
                      <td>
                        <button
                          className="active-btn"
                          style={{
                            backgroundColor: product.isActive
                              ? "#198754"
                              : "#dc3545",
                          }}
                          onClick={() => toggleStatus(product.productId)}
                        >
                          <h3>{product.isActive ? "Active" : "Inactive"}</h3>
                        </button>
                      </td>
                    </tr>
                  ))}
                {emptyRows > 0 &&
                  Array.from(Array(emptyRows)).map((_, index) => (
                    <tr key={`empty-${index}`} style={{ height: 53 }}>
                      <td colSpan={7} />
                    </tr>
                  ))}
              </tbody>

              <tfoot>
                <tr>
                  <td colSpan={7}>
                    <TablePagination
                      rowsPerPageOptions={[]}
                      component="div"
                      count={filteredProducts.length}
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      sx={{ "& p": { margin: 0 }, padding: 0 }}
                    />
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </Grid>
      </Grid>
    </div>
  );
}
