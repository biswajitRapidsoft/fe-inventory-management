import {
  Grid,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { apiEndPoint, baseUrl } from "../../config/config";
import { useNavigate } from "react-router-dom";

export default function OrderHistory() {
  const [orders, setOrders] = useState([]);
  const adminDetails = JSON.parse(localStorage.getItem("loginDetails"));
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrderHistory();
  }, []);

  const fetchOrderHistory = async () => {
    try {
      const response = await axios.get(
        `${baseUrl}${apiEndPoint.orderHistory}?adminId=${adminDetails.adminId}&page=1&size=10`,
        {
          headers: {
            Authorization: "Bearer " + adminDetails?.jwtToken,
          },
        }
      );
      setOrders(response.data);
    } catch (error) {
      console.error("Error fetching order history:", error);
    }
  };

  const openOrderDetails = (order) => {
    navigate("/landingpage/orderhistory/orderdetails", { state: { order } });
  };

  return (
    <Grid container className="order-histories-container">
      <Grid item xs={12} sx={{ height: "fit-content" }}>
        <Typography
          variant="h5"
          sx={{ textDecoration: "underline", marginBottom: "10px" }}
          textAlign="center"
        >
          Order History
        </Typography>
      </Grid>

      <Grid item xs={12} sx={{ height: "calc(100% - 42px)" }}>
        {orders.length > 0 ? (
          <TableContainer
            component={Paper}
            className="order-history-table-container"
          >
            <Table aria-label="order history table" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell className="tHead">
                    <h4>Customer Name</h4>
                  </TableCell>
                  <TableCell className="tHead" align="center">
                    <h4>Phone Number</h4>
                  </TableCell>
                  <TableCell className="tHead" align="center">
                    <h4>Total Amount</h4>
                  </TableCell>
                  <TableCell className="tHead" align="center">
                    <h4>Description</h4>
                  </TableCell>
                  <TableCell className="tHead" align="center">
                    <h4>Date</h4>
                  </TableCell>
                  <TableCell className="tHead" align="center">
                    <h4>Action</h4>
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody className="order-history-tbody">
                {orders.map((order) => (
                  <TableRow key={order.date}>
                    <TableCell component="th" scope="row">
                      {order.customerName}
                    </TableCell>
                    <TableCell align="left">{order.phoneNo}</TableCell>
                    <TableCell align="left">
                      ₹{order.totalAmount.toFixed(2)}
                    </TableCell>
                    <TableCell align="left">{order.description}</TableCell>
                    <TableCell align="left">
                      {new Date(order.date).toLocaleString()}
                    </TableCell>
                    <TableCell align="right">
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={() => openOrderDetails(order)}
                      >
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <Typography textAlign="center">No orders found</Typography>
        )}
      </Grid>
    </Grid>
  );
}
