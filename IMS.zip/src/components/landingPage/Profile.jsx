import { Button, Grid, Typography } from "@mui/material";
import React from "react";
import Img from "../../img/user-image.avif";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const adminDetails = JSON.parse(localStorage.getItem("loginDetails"));
  const navigate = useNavigate();

  const handleLogOut = () => {
    localStorage.removeItem("loginDetails");
    navigate("/");
  };

  return (
    <Grid container className="profile" sx={{ height: "100%" }}>
      <Grid item container className="pic-info" justifyContent="space-between">
        <Grid item className="pf-info" gap={1} xs={8}>
          <Grid container className="name">
            <Grid item xs={4}>
              <Typography variant="body1">Name:</Typography>
            </Grid>
            <Grid item xs={8}>
              <Typography variant="body1">{adminDetails.userName}</Typography>
            </Grid>
          </Grid>
          <Grid container className="userId">
            <Grid item xs={4}>
              <Typography variant="body1">User ID:</Typography>
            </Grid>
            <Grid item xs={8}>
              <Typography variant="body1">{adminDetails.adminId}</Typography>
            </Grid>
          </Grid>
          <Grid container className="email">
            <Grid item xs={4}>
              <Typography variant="body1">Email:</Typography>
            </Grid>
            <Grid item xs={8}>
              <Typography variant="body1">{adminDetails.email}</Typography>
            </Grid>
          </Grid>
        </Grid>

        <Grid item xs={4} className="pic">
          <img
            src={Img}
            alt="Profile"
            // style={{ height: "300px", width: "300px", borderRadius: "10px" }}
          />
        </Grid>
      </Grid>

      <Grid item xs={12} className="logout-btn-div" sx={{ marginTop: "20px" }}>
        <Button variant="contained" onClick={handleLogOut}>
          Log Out
        </Button>
      </Grid>
    </Grid>
  );
}
