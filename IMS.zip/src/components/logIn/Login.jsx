import React, { useState } from "react";
import { Container, TextField, Button, Typography, Paper } from "@mui/material";
import { getLogin } from "../../actions/loginAction";
import { NavLink, useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const loginbody = {
      email: email,
      password: password,
    };

    try {
      const fetchedlogin = await getLogin(loginbody);

      navigate("/landingpage/dashboard");
    } catch (error) {
      console.error("Error while login:", error);
    }
  };

  return (
    <Container maxWidth="xs">
      <Paper elevation={8} sx={{ padding: 4, marginTop: 14 }}>
        <Typography
          variant="h3"
          sx={{ textDecoration: "underline" }}
          textAlign="center"
        >
          Login
        </Typography>
        <form onSubmit={handleSubmit} sx={{ mt: 1 }}>
          <TextField
            type="email"
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="email"
            label="Email Address"
            name="email"
            autoFocus
            value={email}
            onChange={handleEmailChange}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            value={password}
            onChange={handlePasswordChange}
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            sx={{ mt: 3, mb: 2 }}
          >
            Login
          </Button>
        </form>

        <NavLink style={{ marginTop: "10px" }} to={"/signup"}>
          Don't have an account? Sign Up
        </NavLink>
      </Paper>
    </Container>
  );
};

export default Login;
