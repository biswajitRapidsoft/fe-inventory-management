// Subham
export const baseUrl = "http://192.168.12.57:8080/admin";

export const apiEndPoint = {
  login: "/login",
  signup: "/signup",
  allProduct: "/product/all",
  addEditProduct: "/product/create-update",
  createOrder: "/product/sales",
  orderHistory: "/invoice",
};

// Udit
// export const baseUrl = "http://192.168.12.48:8080/ims";

// export const apiEndPoint = {
//   login: "/signin",
//   signup: "/signup",
//   allProduct: "/getProducts",
//   addEditProduct: "/addProduct",
//   createOrder: "/product/sales",
// };

// Surya
// export const baseUrl = "http://192.168.12.55:8008/IMS";

// export const apiEndPoint = {
//   login: "/login",
//   signup: "/signup",
//   allProduct: "/allproducts",
//   addEditProduct: "/addProduct",
//   // createOrder: "/product/sales",
// };
