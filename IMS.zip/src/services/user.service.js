import axios from "axios";
import { baseUrl, apiEndPoint } from "../config/config";

export const fetchLogin = async (loginbody) => {
  try {
    const response = await axios.post(
      `${baseUrl}${apiEndPoint.login}`,
      loginbody
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const fetchSignup = async (signupbody) => {
  try {
    const response = await axios.post(
      `${baseUrl}${apiEndPoint.signup}`,
      signupbody
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};
